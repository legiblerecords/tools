{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "BUW5n4L4NSqGMuC_gxi0P8RcUKeAbc3-kCcNoVuVqancfE2Dz6YP7yjPG6JBIFhTv3gIUzuobvMOwOrumgsTBw"
}
