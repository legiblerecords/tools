{
  "alg": "ed25519",
  "key": "2025-06",
  "publisher": "acme.example",
  "signature": "Ua3Jond7zgOg7sX5RfkWpDzGN5SB3sfl3u_URZlK5g06IbRFPguxWNJqjYLzqivrw7DfLFcVxhamXkQyEf_CCA"
}
