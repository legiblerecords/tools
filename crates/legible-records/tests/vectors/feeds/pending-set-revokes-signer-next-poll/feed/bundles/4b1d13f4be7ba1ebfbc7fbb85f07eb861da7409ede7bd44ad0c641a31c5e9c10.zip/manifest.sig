{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "VP37s922Os7AYMemfujz4WWo9rc2EfsrvbzEQbSlZ2G4lrpRpH3pvFQTkQmdk5FO3jY2dlc37IvmgPnh3FYkBg"
}
