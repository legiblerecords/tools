{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "LvtNtdjqAN7T7cKjXlUJu7lEmwvix7HR_iiYkva31BPRsnIXJOyUz3VI6QlAMNqu55WxZ5ntETTNq-RJAivKDw"
}
