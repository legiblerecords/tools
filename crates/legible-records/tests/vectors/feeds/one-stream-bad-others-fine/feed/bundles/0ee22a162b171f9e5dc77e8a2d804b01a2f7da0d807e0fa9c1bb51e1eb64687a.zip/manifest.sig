{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "-Ebnb84iqfnnx5Si6xYwilwNBO5YCPV_OIzY83FALASlSgSQYq7Tq_z70QsQCwaYRtel6grp-BuWXpWqDwo5BA"
}
