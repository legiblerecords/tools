{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "gxBlXAdbaC6cIQP2idM8cZLaz526L7ecPzKPG97GpSC6_1gzsnDb_vYs4WJip0ukPh_MoGBXWrz3rL9jwF8DDQ"
}
