{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "qHmlIy0Wqg7lUKYpC5g-LwWCu9v3vzkSv_Am_1uyQ-qzFUphskxlGMCrHCEm4HbG9PG6iKE6qojMJlQna0saCA"
}
