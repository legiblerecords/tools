{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "f_sTVU6RiGlh3M3PohqR35HT-FKXSle1J-XWiZRctrwMcZSveK2cwZMJyn8FDI6nbzcxziXE0IbJCvsvS7SFCw"
}
