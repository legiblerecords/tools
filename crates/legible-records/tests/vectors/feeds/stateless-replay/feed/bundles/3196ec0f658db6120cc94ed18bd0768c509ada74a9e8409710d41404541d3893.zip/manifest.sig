{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "j_3pP3IY1gXr-VNQ_5BwQUQmpqfcJ0TOvstHpTq7Px_4rDBMYJPbq83PhAqa891QQlroVrbSwN_79TaHB7VmAQ"
}
