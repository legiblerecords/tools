{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "jHr6jpb1kkWV3wGmjaCGS-fiTY2oPaFZEKgyuQ_R8A_9op8Z4bJqFS3jc_TjUmqNEBfxXG3xzPNwVnffhLurCw"
}
