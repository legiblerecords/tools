{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "NkxySjQi50lJ7ts-iGiEJjJt3sSsR7Bb72OWw9_iBP53MV7mCTCIz0-TOYfRYZckTQQe1MhEUT4Xet1ekBdfCg"
}
