{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "7zQ6BpijLi4snXvuoH3S10WbO7MtukkO-8NON_YyoiRIk195KTiorhSO9M3pkiFLZdXPFrZSJB2f6xKI8NsGDA"
}
