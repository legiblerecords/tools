{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "9m88BbIAeNH8jtXvP1Ty4WMmkKCkqN6xdwz9heHZUt3fhUqIBHXZejLqPlC6zXYMM7tsjs8jFRDDTpwZMhH_Cw"
}
