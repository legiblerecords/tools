{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "7DPU6-vMUJzGaqDr4UARRESt5X5t7p5nsS3OtjPzCqfb1_eYe4BpkBYvK3Aeju43qKRpgXz3iN2y8X1ajXsGCg"
}
