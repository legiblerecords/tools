{
  "alg": "ed25519",
  "key": "2027-03",
  "publisher": "acme.example",
  "signature": "6jkah6Rp7plxUOtX9uQvlwUwO9pIhIXRTwCw8fhiGQlOySlNki0WSZ5Wkns86poyua77E3dXEAfCjb6xEaMTAQ"
}
