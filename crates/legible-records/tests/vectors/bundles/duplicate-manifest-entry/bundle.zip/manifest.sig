{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "R89MKb2eOGuy0S2xc1BS50jMblAWuhAcApW-oRFc3F5USbAqpafGxpAI1bc6eVFIZMxPAu-yOIgnFuDAnIpkCQ"
}
