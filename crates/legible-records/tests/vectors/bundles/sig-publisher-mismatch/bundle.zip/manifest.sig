{
  "alg": "ed25519",
  "key": "1",
  "publisher": "other.example",
  "signature": "gx5LHfD3daMyl9gk_IUI8HSz5vX3vy-z8TrXwByXS4AsEYTjFtK8Sh2hVZaTg-kvghmx6yhU0H_A9BHPjL4YBA"
}
