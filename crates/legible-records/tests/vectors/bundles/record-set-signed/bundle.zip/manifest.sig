{
  "alg": "ed25519",
  "key": "2026-11",
  "publisher": "acme.example",
  "signature": "Pm0OJlzt41hy0apGgddDnl0tYmTMX2k4Ro4dpANkrJIdO4oKZOksc-tfcK11Gxx8ZVCWDs2xJtQR37POUyQmAw"
}
